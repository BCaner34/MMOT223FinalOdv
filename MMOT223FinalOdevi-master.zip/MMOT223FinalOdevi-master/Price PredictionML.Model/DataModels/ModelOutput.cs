//*****************************************************************************************
//*                                                                                       *
//* This is an auto-generated file by Microsoft ML.NET CLI (Command-Line Interface) tool. *
//*                                                                                       *
//*****************************************************************************************

using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.ML.Data;

namespace PremLig.PredictionML.Model.DataModels
{
    public class ModelOutput
{
        public float Score { get; set; }
}
}
